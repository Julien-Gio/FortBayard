/********************************************************************************
** Form generated from reading UI file 'menuwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.14.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MENUWINDOW_H
#define UI_MENUWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MenuWindow
{
public:
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer_2;
    QLabel *label_3;
    QPushButton *EasyBtn;
    QPushButton *NormalBtn;
    QPushButton *HardBtn;
    QSpacerItem *horizontalSpacer_3;
    QHBoxLayout *horizontalLayout_3;
    QSpacerItem *horizontalSpacer_5;
    QLabel *label_2;
    QPushButton *KeyboardBtn;
    QPushButton *CameraBtn;
    QSpacerItem *horizontalSpacer_6;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer;
    QPushButton *StartBtn;
    QSpacerItem *horizontalSpacer_4;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MenuWindow)
    {
        if (MenuWindow->objectName().isEmpty())
            MenuWindow->setObjectName(QString::fromUtf8("MenuWindow"));
        MenuWindow->resize(1217, 562);
        centralwidget = new QWidget(MenuWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        verticalLayout = new QVBoxLayout(centralwidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setMinimumSize(QSize(0, 190));
        QFont font;
        font.setPointSize(76);
        font.setBold(true);
        font.setUnderline(false);
        font.setWeight(75);
        label->setFont(font);
        label->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_2);

        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setMinimumSize(QSize(150, 0));
        QFont font1;
        font1.setPointSize(18);
        label_3->setFont(font1);

        horizontalLayout->addWidget(label_3);

        EasyBtn = new QPushButton(centralwidget);
        EasyBtn->setObjectName(QString::fromUtf8("EasyBtn"));
        EasyBtn->setMinimumSize(QSize(0, 80));
        QFont font2;
        font2.setPointSize(16);
        EasyBtn->setFont(font2);
        EasyBtn->setCursor(QCursor(Qt::PointingHandCursor));
        EasyBtn->setFlat(true);

        horizontalLayout->addWidget(EasyBtn);

        NormalBtn = new QPushButton(centralwidget);
        NormalBtn->setObjectName(QString::fromUtf8("NormalBtn"));
        NormalBtn->setMinimumSize(QSize(0, 80));
        QFont font3;
        font3.setPointSize(32);
        NormalBtn->setFont(font3);
        NormalBtn->setCursor(QCursor(Qt::PointingHandCursor));
        NormalBtn->setFlat(true);

        horizontalLayout->addWidget(NormalBtn);

        HardBtn = new QPushButton(centralwidget);
        HardBtn->setObjectName(QString::fromUtf8("HardBtn"));
        HardBtn->setMinimumSize(QSize(0, 80));
        HardBtn->setFont(font2);
        HardBtn->setCursor(QCursor(Qt::PointingHandCursor));
        HardBtn->setFlat(true);

        horizontalLayout->addWidget(HardBtn);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_3);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_5);

        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setMinimumSize(QSize(145, 0));
        label_2->setFont(font1);

        horizontalLayout_3->addWidget(label_2);

        KeyboardBtn = new QPushButton(centralwidget);
        KeyboardBtn->setObjectName(QString::fromUtf8("KeyboardBtn"));
        KeyboardBtn->setMinimumSize(QSize(0, 80));
        KeyboardBtn->setFont(font2);
        KeyboardBtn->setFlat(true);

        horizontalLayout_3->addWidget(KeyboardBtn);

        CameraBtn = new QPushButton(centralwidget);
        CameraBtn->setObjectName(QString::fromUtf8("CameraBtn"));
        CameraBtn->setMinimumSize(QSize(0, 80));
        CameraBtn->setFont(font3);
        CameraBtn->setFlat(true);

        horizontalLayout_3->addWidget(CameraBtn);

        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_6);


        verticalLayout->addLayout(horizontalLayout_3);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        StartBtn = new QPushButton(centralwidget);
        StartBtn->setObjectName(QString::fromUtf8("StartBtn"));
        StartBtn->setMinimumSize(QSize(270, 105));
        QFont font4;
        font4.setPointSize(36);
        font4.setBold(true);
        font4.setWeight(75);
        StartBtn->setFont(font4);
        StartBtn->setCursor(QCursor(Qt::PointingHandCursor));
        StartBtn->setCheckable(false);

        horizontalLayout_2->addWidget(StartBtn);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_4);


        verticalLayout->addLayout(horizontalLayout_2);

        MenuWindow->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(MenuWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MenuWindow->setStatusBar(statusbar);
        QWidget::setTabOrder(StartBtn, EasyBtn);
        QWidget::setTabOrder(EasyBtn, NormalBtn);
        QWidget::setTabOrder(NormalBtn, HardBtn);

        retranslateUi(MenuWindow);

        StartBtn->setDefault(true);


        QMetaObject::connectSlotsByName(MenuWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MenuWindow)
    {
        MenuWindow->setWindowTitle(QCoreApplication::translate("MenuWindow", "MainWindow", nullptr));
        label->setText(QCoreApplication::translate("MenuWindow", "Labyrinthe 3D", nullptr));
        label_3->setText(QCoreApplication::translate("MenuWindow", "Difficult\303\251 :", nullptr));
        EasyBtn->setText(QCoreApplication::translate("MenuWindow", "\360\237\221\266", nullptr));
        NormalBtn->setText(QCoreApplication::translate("MenuWindow", "\360\237\230\203", nullptr));
        HardBtn->setText(QCoreApplication::translate("MenuWindow", "\360\237\230\210", nullptr));
        label_2->setText(QCoreApplication::translate("MenuWindow", "Contr\303\264le :", nullptr));
        KeyboardBtn->setText(QCoreApplication::translate("MenuWindow", "\342\214\250", nullptr));
        CameraBtn->setText(QCoreApplication::translate("MenuWindow", "\360\237\216\245", nullptr));
        StartBtn->setText(QCoreApplication::translate("MenuWindow", "Start !", nullptr));
#if QT_CONFIG(shortcut)
        StartBtn->setShortcut(QCoreApplication::translate("MenuWindow", "Return", nullptr));
#endif // QT_CONFIG(shortcut)
    } // retranslateUi

};

namespace Ui {
    class MenuWindow: public Ui_MenuWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MENUWINDOW_H
